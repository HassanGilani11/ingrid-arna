const e=()=>{$(".magazine-logos-marquee").marquee({duration:125e3,gap:0,delayBeforeStart:0,direction:"left",duplicated:!0,startVisible:!0})};$(document).ready(function(){e()});
